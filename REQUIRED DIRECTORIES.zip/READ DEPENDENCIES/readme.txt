These are required or cheat will crash put them in these locations.

"gsws" and "luas" folder in "C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive" 
"sb" folder in "C:"